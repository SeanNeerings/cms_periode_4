<aside class="col-4">
  <div class="infosquare">
    <h5>It's all about</h5>
    <h3>Fitness first</h3>
    <i class="fas fa-tint icon"></i>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
      eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
      enim ad minim veniam, quis nostrud.
    </p>
    <a href="#">Read More</a>
  </div>
  <div class="">
    <img src=imgs/fitness.jpg class='img-fluid img-fit' alt='Fitness girl'>
  </div>
  <div class="infosquare">
    <h5>Love your</h5>
    <h3>Own body</h3>
    <i class="fas fa-heart icon"></i>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
      eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
      enim ad minim veniam, quis nostrud.
    </p>
    <a href="#">Read More</a>
  </div>
  <div class="">
    <img src=imgs/watch.jpg class='img-fluid img-fit' alt='Smartwatch'>
  </div>

  <?php dynamic_sidebar( 'sidebar-widgets' ); ?>
  
</aside>